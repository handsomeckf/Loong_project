
#include "ls1x.h"
#include "Config.h"
#include "ls1x_gpio.h"
#include "ls1x_latimer.h"
#include "esp8266.h"
#include "ls1c102_interrupt.h"
#include "sensers.h"

#define LED 20

int main(int arg, char *args[])
{

    esp8266_init();

    int value=0;
    AFIO_RemapConfig(AFIOB, GPIO_Pin_4, 0);
    Adc_powerOn();
    Adc_open(ADC_CHANNEL_I5);

    while(1)
    {
        gpio_write_pin(LED,1);
        value=Adc_Measure(ADC_CHANNEL_I5);
        value1=Adc_Measure(ADC_CHANNEL_I6);
        printf("%d\r\n",value/3.7);
        gpio_pin_remap(GPIO_PIN_4,GPIO_FUNC_MAIN);
        gpio_pin_remap(GPIO_PIN_5,GPIO_FUNC_MAIN);

        senser_light();
        senser_tempre();
        senser_humidity();
        senser_smokes();
        senser_alldataout();

        I2C_InitTypeDef I2C_InitStruct0;
        I2C_StructInit(&I2C_InitStruct0);
        gpio_write_pin(LED,0);
        delay_ms(50);
    }

    return 0;
}
