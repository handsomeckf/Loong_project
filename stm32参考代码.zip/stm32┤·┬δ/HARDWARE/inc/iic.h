#ifndef __IIC_H
#define __IIC_H

#include "stm32f10x.h"

/*--------------------------------------------------------------------------*/
/*                      ����LED��IO���� �� ʱ��ʹ��                         */
/*                        ���Ը�����Ҫ�޸ĺ�����                            */
/*--------------------------------------------------------------------------*/
#define SDA_GROUP             GPIOC                                               //SDA ��Ӧ��IO����
#define SDA_PIN               GPIO_Pin_14                                         //SDA ��Ӧ��IO
#define SDA_GROUP_CLK_ENABLE  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC,ENABLE);

#define SCL_GROUP             GPIOC                                               //SCL ��Ӧ��IO����
#define SCL_PIN               GPIO_Pin_13                                          //SCL ��Ӧ��IO
#define SCL_GROUP_CLK_ENABLE  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC,ENABLE);
/*--------------------------------------------------------------------------*/
  		   

#define READ_SDA        GPIO_ReadInputDataBit(SDA_GROUP, SDA_PIN)                               //��ȡSDA��ƽ 
#define IIC_SDA_OUT(x)  GPIO_WriteBit(SDA_GROUP, SDA_PIN, (BitAction)x)            //����SDA��ƽ 

#define	IIC_SCL_H       GPIO_SetBits(SCL_GROUP, SCL_PIN)                //SCL����
#define	IIC_SDA_H      	GPIO_SetBits(SDA_GROUP, SDA_PIN)                //SDA����
 
#define	IIC_SCL_L       GPIO_ResetBits(SCL_GROUP, SCL_PIN)              //SCL����
#define	IIC_SDA_L       GPIO_ResetBits(SDA_GROUP, SDA_PIN)              //SDA����
 
void IIC_Init(void);
void IIC_Start(void);
void IIC_Stop(void);
char IIC_Wait_Ack(void);
void IIC_Send_Byte(uint8_t);
unsigned char IIC_Read_Byte(uint8_t);

#endif
