#ifndef __WIFI_H
#define __WIFI_H

#include "stm32f10x.h"
#include "usart2.h"	      

extern char Connect_flag;  

#define RESET_IO(x)    GPIO_WriteBit(GPIOA, GPIO_Pin_4, (BitAction)x) 

#define WiFi_printf       u2_printf       
#define WiFi_RxCounter    Usart2_RxCounter    
#define WiFi_RX_BUF       Usart2_RxBuff       
#define WiFi_RXBUFF_SIZE  USART2_RXBUFF_SIZE  

#define SSID   "Hi nova 9_plus"                     
#define PASS   "12345678"                 

void WiFi_ResetIO_Init(void);
char WiFi_SendCmd(char *cmd, int timeout);
char WiFi_Reset(int timeout);
char WiFi_JoinAP(int timeout);
char WiFi_Connect_Server(int timeout);
char WiFi_Smartconfig(int timeout);
char WiFi_WaitAP(int timeout);
char WiFi_GetIP(uint16_t timeout);
char WiFi_Get_LinkSta(void);
char WiFi_Get_Data(char *data, char *len, char *id);
char WiFi_SendData(char id, char *databuff, int data_len, int timeout);
char WiFi_Connect_Server(int timeout);
char WiFi_ConnectServer(void);

#endif


