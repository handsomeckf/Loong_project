#ifndef __FIRE2_H
#define __FIRE2_H

#include "stm32f10x.h"

#define temp_threshold 40
#define humi_threshold 80
#define light_threshold 60000
#define gradum 20
#define max_gradum 5
#define humi_max_gradum 18
#define window_len_temp 4
#define window_len_humi 5

typedef struct Grad
{
	int gradList[gradum];
	float current;
	int begin;
}Grad;

int sum_grad(Grad *grad);
void updata_grad(Grad *grad, float data);
void updata_grad_humi(Grad *grad, float data);
float updata_avr_temp(float);
float updata_avr_humi(float);
uint8_t is_abnormal(float, float, uint16_t);

#endif
