#ifndef __FIRE_H
#define __FIRE_H

#include "stm32f10x.h"

#define temp_threshold 40
#define humi_threshold 80
#define light_threshold 60000
#define gradum 30
#define max_gradum 15
#define humi_max_gradum 25

typedef struct Grad
{
	int gradList[gradum];
	float current;
	int begin;
}Grad;

int sum_grad(Grad *grad);
void updata_grad(Grad *grad, float data);
uint8_t is_abnormal(float, float, uint16_t);

#endif
