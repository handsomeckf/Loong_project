#ifndef __BH1750_H
#define __BH1750_H

#include "stm32f10x.h"

#define BH1750_SDA GPIO_Pin_6
#define BH1750_SCL GPIO_Pin_5
#define BH1750_Address 0x23

#define BH1750_SCL_HIGH GPIO_SetBits(GPIOA, BH1750_SCL)
#define BH1750_SCL_LOW GPIO_ResetBits(GPIOA, BH1750_SCL)
#define BH1750_SDA_HIGH GPIO_SetBits(GPIOA, BH1750_SDA)
#define BH1750_SDA_LOW GPIO_ResetBits(GPIOA, BH1750_SDA)

void BH1750_START(void);
void BH1750_STOP(void);
void BH1750_Send_ACK(uint8_t ack);
uint8_t BH1750_Rcv_ACK(void);
uint8_t BH1750_Wait_ACK(void);
void BH1750_Send_Bye(uint8_t send);
uint8_t BH1750_Read_Byte(void);
void BH1750_Init(void);
void BH1750_Read(uint16_t* data);

#endif
