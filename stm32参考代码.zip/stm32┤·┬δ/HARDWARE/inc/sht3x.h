#ifndef __SHT3X_H
#define __SHT3X_H

#include "stm32f10x.h"

#define SHT3X_SCL GPIO_Pin_1
#define SHT3X_SDA GPIO_Pin_0
#define SHT3X_Address (uint8_t)(0x44 << 1)
#define Write_CMD 0xFE
#define Read_CMD 0x01

#define SHT3X_SCL_HIGH GPIO_SetBits(GPIOA, SHT3X_SCL)
#define SHT3X_SCL_LOW GPIO_ResetBits(GPIOA, SHT3X_SCL)
#define SHT3X_SDA_HIGH GPIO_SetBits(GPIOA, SHT3X_SDA)
#define SHT3X_SDA_LOW GPIO_ResetBits(GPIOA, SHT3X_SDA)

typedef enum{
	ACK = Bit_RESET,
	NACK = Bit_SET,
}ACK_Value_t;

void SHT3X_I2C_Init(void);
void SHT3X_I2C_Start(void);
void SHT3X_I2C_Stop(void);
static ACK_Value_t SHT3X_Write_Byte(uint8_t send);
uint8_t SHT3X_Read_Byte(ACK_Value_t ACK_Value);
void SHT3X_Init(void);
void SHT3X_Read(float* Hum, float* Temp);
uint8_t SHT3X_Check(uint8_t *Crc_ptr, uint8_t LEN);

#endif
