#include "sht3x.h"
#include "delay.h"
#include "stm32f10x.h"

void SHT3X_I2C_Init(void)
{
	SHT3X_SCL_HIGH;
	SHT3X_SDA_HIGH;
}

void SHT3X_I2C_Start(void)
{
	SHT3X_SDA_HIGH;
	SHT3X_SCL_HIGH;
	Delay_Us(1);
	SHT3X_SDA_LOW;
	Delay_Us(10);
	SHT3X_SCL_LOW;
	Delay_Us(1);
}

void SHT3X_I2C_Stop(void)
{
	SHT3X_SDA_LOW;
	SHT3X_SCL_HIGH;;
	Delay_Us(1);
	Delay_Us(10);
	SHT3X_SDA_HIGH;
}

static ACK_Value_t SHT3X_Write_Byte(uint8_t send)
{
	uint8_t i;
	ACK_Value_t ACK_Respond;
	for (i=0; i<8; i++)
	{
		SHT3X_SCL_LOW;
		Delay_Us(1);
		if (send & 0x80)
		{
			SHT3X_SDA_HIGH;
		}
		else SHT3X_SDA_LOW;
		Delay_Us(1);
		SHT3X_SCL_HIGH;
		Delay_Us(10);
		send <<= 1;
	}
	SHT3X_SCL_LOW;
	SHT3X_SDA_HIGH;
	Delay_Us(1);
	SHT3X_SCL_HIGH;
	Delay_Us(10);
	ACK_Respond = (ACK_Value_t)GPIO_ReadInputDataBit(GPIOA, SHT3X_SDA);
	SHT3X_SCL_LOW;
	Delay_Us(1);
	return ACK_Respond;
}

uint8_t SHT3X_Read_Byte(ACK_Value_t ACK_Value)
{
	uint8_t i;
	uint8_t data = 0;
	for (i=0; i<8; i++)
	{
		data <<= 1;
		SHT3X_SCL_LOW;
		Delay_Us(10);
		SHT3X_SCL_HIGH;
		Delay_Us(10);
		data |= GPIO_ReadInputDataBit(GPIOA, SHT3X_SDA);
	}
	SHT3X_SCL_LOW;
	Delay_Us(1);
	if (ACK_Value == ACK)
		SHT3X_SDA_LOW;
	else SHT3X_SDA_HIGH;
	Delay_Us(1);
	SHT3X_SCL_HIGH;
	Delay_Us(10);
	SHT3X_SCL_LOW;
	SHT3X_SDA_HIGH;
	Delay_Us(1);
		return data;
}

void SHT3X_Init(void)
{
	GPIO_InitTypeDef GPIO_Initstruct = {0};
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	GPIO_Initstruct.GPIO_Pin = SHT3X_SCL | SHT3X_SDA;
	GPIO_Initstruct.GPIO_Mode = GPIO_Mode_Out_OD;
	GPIO_Initstruct.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_Initstruct);	
}

void SHT3X_Read(float* Hum, float* Temp)
{
	uint8_t buf[6];
	uint16_t temp_uint = 0;
	uint8_t check;
	float temp_float = 0;
	uint8_t i;
	SHT3X_I2C_Start();
	SHT3X_Write_Byte(SHT3X_Address & Write_CMD);
	SHT3X_Write_Byte(0x27);
	SHT3X_Write_Byte(0x37);
	do
	{
		check++;
		SHT3X_I2C_Start();
		SHT3X_Write_Byte(SHT3X_Address & Write_CMD);
		SHT3X_Write_Byte(0xE0);
		SHT3X_Write_Byte(0x00);
		SHT3X_I2C_Start();
	}
	while((SHT3X_Write_Byte(SHT3X_Address | Read_CMD) == NACK) && check < 100);
	for (i = 0; i < 5; i++)
	{
		buf[i] = SHT3X_Read_Byte(ACK);
	}
	buf[i] = SHT3X_Read_Byte(NACK);
	SHT3X_I2C_Stop();
	if (SHT3X_Check(buf, 2) == buf[2])
	{
		temp_uint = buf[0] * 256 + buf[1];
		temp_float = (float)temp_uint * 175 / (65536 - 1) - 45;
		*Temp = temp_float;
	}
	if (SHT3X_Check(&buf[3], 2) == buf[5])
	{
		temp_uint = buf[3] * 256 + buf[4];
		temp_float = 100 * (float)temp_uint / (65536 - 1);
		*Hum = temp_float;
	}
}

uint8_t SHT3X_Check(uint8_t *Crc_ptr, uint8_t LEN)
{
	uint8_t CRC_Value = 0xFF;
	uint8_t i = 0, j = 0;
	for (i=0; i<LEN; i++)
	{
		CRC_Value ^= *(Crc_ptr + i);
		for (j=0; j<8; j++)
		{
			if (CRC_Value & 0x80)
				CRC_Value = (CRC_Value << 1) ^ 0x31;
			else CRC_Value = (CRC_Value << 1);
		}
	}
	return CRC_Value;
}
