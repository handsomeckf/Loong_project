#include "bh1750.h"
#include "stm32f10x.h"
#include "delay.h"
#include "usart1.h"

void BH1750_START(void)
{
	BH1750_SDA_HIGH;
	BH1750_SCL_HIGH;
	Delay_Us(10);
	BH1750_SDA_LOW;
	Delay_Us(10);
	BH1750_SCL_LOW;
}

void BH1750_STOP(void)
{
	BH1750_SDA_LOW;
	BH1750_SCL_HIGH;
	Delay_Us(10);
	BH1750_SDA_HIGH;
	Delay_Us(10);
}

void BH1750_Send_ACK(uint8_t ack)
{
	GPIO_InitTypeDef GPIO_Initstruct = {0};
	GPIO_Initstruct.GPIO_Pin = BH1750_SDA;
	GPIO_Initstruct.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Initstruct.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_Initstruct);
	
	if (ack == 1)
	{
		BH1750_SDA_HIGH;
	}
	else if(ack == 0)
		BH1750_SDA_LOW;
	BH1750_SCL_HIGH;
	Delay_Us(10);
	BH1750_SCL_LOW;
	Delay_Us(10);
}

uint8_t BH1750_Rcv_ACK(void)
{
	uint8_t ack ;
	GPIO_InitTypeDef GPIO_Initstruct = {0};
	GPIO_Initstruct.GPIO_Pin = BH1750_SDA;
	GPIO_Initstruct.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_Initstruct.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_Initstruct);
	
	BH1750_SCL_HIGH;
	Delay_Us(10);
	if (GPIO_ReadInputDataBit(GPIOA, BH1750_SDA) == Bit_SET)
		ack = 1;
	else 
		ack = 0;
	BH1750_SCL_LOW;
	Delay_Us(10);
	GPIO_Initstruct.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(GPIOA, &GPIO_Initstruct);
	return ack;
}

uint8_t BH1750_Wait_ACK(void)
{
	uint8_t err = 0;
	Delay_Us(10);
	BH1750_SDA_HIGH;
	Delay_Us(10);
	BH1750_SCL_HIGH;
	Delay_Us(10);
	while(GPIO_ReadInputDataBit(GPIOA, BH1750_SDA))
	{
		err ++;
		if (err > 250)
		{
			BH1750_STOP();
			return 1;
		}
	}
	Delay_Us(10);
	BH1750_SCL_LOW;
	return 0;
}

void BH1750_Send_Byte(uint8_t send)
{
	uint8_t i;
	for (i=0; i<8; i++)
	{
		if (send & 0x80)
		{
			BH1750_SDA_HIGH;
		}
		else BH1750_SDA_LOW;
		send <<= 1;
		BH1750_SCL_HIGH;
		Delay_Us(10);
		BH1750_SCL_LOW;
		Delay_Us(10);
	}
	BH1750_Rcv_ACK();
}

uint8_t BH1750_Read_Byte(void)
{
	uint8_t i;
	uint8_t data = 0;
	
	GPIO_InitTypeDef GPIO_Initstruct = {0};
	GPIO_Initstruct.GPIO_Pin = BH1750_SDA;
	GPIO_Initstruct.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_Initstruct.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_Initstruct);
	
	for (i=0; i<8; i++)
	{
		data <<= 1;
		BH1750_SCL_HIGH;
		Delay_Us(10);
		if(GPIO_ReadInputDataBit(GPIOA, BH1750_SDA) == Bit_SET)
		{
			data |= 0x01;
		}
		else data |= 0x00;
		BH1750_SCL_LOW;
		Delay_Us(10);
	}
	GPIO_Initstruct.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(GPIOA, &GPIO_Initstruct);
	return data;
}

void BH1750_Init(void)
{
	GPIO_InitTypeDef GPIO_Initstruct = {0};
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	GPIO_Initstruct.GPIO_Pin = BH1750_SCL | BH1750_SDA;
	GPIO_Initstruct.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Initstruct.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_Initstruct);
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);
	GPIO_Initstruct.GPIO_Pin =GPIO_Pin_15;
	GPIO_Initstruct.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Initstruct.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOC, &GPIO_Initstruct);
	GPIO_ResetBits(GPIOC, GPIO_Pin_15);
	BH1750_START();
	BH1750_Send_Byte(BH1750_Address << 1);
	BH1750_Send_Byte(0x10);
	BH1750_STOP();
	Delay_Ms(180);
}

void BH1750_Read(uint16_t* data)
{
	uint8_t buf[2];
	uint8_t i;
	uint32_t lv_data;
	BH1750_START();
	BH1750_Send_Byte(BH1750_Address << 1);
	Delay_Us(150);
	BH1750_Send_Byte(0x10);
	BH1750_STOP();
	Delay_Ms(180);
	BH1750_START();
	BH1750_Send_Byte((BH1750_Address << 1) | 1);
	for(i=0; i<2; i++)
	{
		buf[i] = BH1750_Read_Byte();
		if(i == 1)
		{
			BH1750_Send_ACK(1);
		}
		else BH1750_Send_ACK(0);
	}
	BH1750_STOP();
	lv_data = ((buf[0] << 8) | buf[1]) * 1000 / 1.2;
	*data = (uint16_t)lv_data;
}
