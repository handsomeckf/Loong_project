#include "fire.h"
#include "stdio.h"

Grad tempGrad = {0};
Grad humGrad = {0};

int sum_grad(Grad *grad)
{
	int sum = 0;
	int i;
	for (i=0; i<gradum; i++)
	{
		sum += grad->gradList[i];
	}
	return sum;
}

void updata_grad(Grad *grad, float data)
{
	if(data - grad->current > 0) grad->gradList[grad->begin] = 1;
    else  grad->gradList[grad->begin] = 0;
    grad->current = data;
    grad->begin = (grad->begin + 1)%gradum;
}

uint8_t is_abnormal(float temp, float humi, uint16_t light)
{
		int tempGradSum;
		int humiGradSum; 
    updata_grad(&tempGrad, temp);
    updata_grad(&humGrad, humi);
    tempGradSum = sum_grad(&tempGrad);
    humiGradSum = sum_grad(&humGrad);
    if(humi > humi_threshold || humiGradSum > humi_max_gradum) return 1; //��ˮ�쳣
    if(temp > temp_threshold || tempGradSum > max_gradum) return 1; //�����쳣
	
    return 0;
}
