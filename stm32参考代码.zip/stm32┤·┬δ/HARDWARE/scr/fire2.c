#include "fire2.h"
#include "stdio.h"
#include "main.h"
#include "queue.h"

Grad tempGrad = {0};
Grad humGrad = {0};
Grad humiGradsub = {0};

float sum_temp = 0;
float sum_humi = 0;
int cur_temp = 0;
int cur_humi = 0;

int sum_grad(Grad *grad)
{
	int sum = 0; 
	int i;
	for (i=0; i<gradum; i++)
	{
		sum += grad->gradList[i];
	}
	return sum;
}

void updata_grad(Grad *grad, float data)
{
	if (grad->current == 0)  grad->gradList[grad->begin] = 0;
	if(data - grad->current > 0.1) grad->gradList[grad->begin] = 1;
    else  grad->gradList[grad->begin] = 0;
    grad->current = data;
    grad->begin = (grad->begin + 1)%gradum;
}

void updata_grad_humi(Grad *grad, float data)
{
	if (grad->current == 0)  grad->gradList[grad->begin] = 0;
	if(data - grad->current < -0.3) grad->gradList[grad->begin] = 1;
    else  grad->gradList[grad->begin] = 0;
    grad->current = data;
    grad->begin = (grad->begin + 1)%gradum;
}

float updata_avr_temp(float data)
{
	cur_temp += 1;
	if (cur_temp <= window_len_temp)
	{
		sum_temp += data;
		QueuePush(&q_temp, data);
		return (sum_temp / cur_temp);
	}
	else{
		sum_temp -= QueueFront(&q_temp);
		sum_temp += data;
		QueuePop(&q_temp);
		QueuePush(&q_temp, data);
		return (sum_temp / window_len_temp);
	}
}

float updata_avr_humi(float data)
{
	cur_humi += 1;
	if (cur_humi <= window_len_humi)
	{
		sum_humi += data;
		QueuePush(&q_humi, data);
		return (sum_humi / cur_humi);
	}
	else{
		sum_humi -= QueueFront(&q_humi);
		sum_humi += data;
		QueuePop(&q_humi);
		QueuePush(&q_humi, data);
		return (sum_humi / window_len_humi);
	}
}

uint8_t is_abnormal(float temp, float humi, uint16_t light)
{
		int tempGradSum;
		int humiGradSum; 
		int humiGradSum_sub;
		float temp_average;
		float humi_average;
		if (temp != 0) 
		{
			temp_average = updata_avr_temp(temp);
			updata_grad(&tempGrad, temp_average);
		}
		if (humi != 0)
		{
			humi_average = updata_avr_humi(humi);
			updata_grad(&humGrad, humi_average);
			updata_grad_humi(&humiGradsub, humi);
		}
    tempGradSum = sum_grad(&tempGrad);
    humiGradSum = sum_grad(&humGrad);
		humiGradSum_sub = sum_grad(&humiGradsub);
    if(humi > humi_threshold || humiGradSum > humi_max_gradum) return 1; //��ˮ�쳣
    if(temp > temp_threshold || (tempGradSum > max_gradum && humiGradSum_sub > max_gradum)) return 1; //�����쳣
    return 0;
}
