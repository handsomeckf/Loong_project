#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include "queue.h"

void QueueInit(Queue* pq)
{
	assert(pq);
	pq->head = pq->tail = NULL;
}

void QueuePush(Queue* pq, QDataType x)
{
	QueueNode* newnode = (QueueNode*)malloc(sizeof(QueueNode));
	assert(pq);
	if (newnode == NULL)
	{
		return;
	}
	else
	{
		newnode->data = x;  
		newnode->next = NULL; 
 
	}
	if (pq->head ==NULL&& pq->tail==NULL)
	{
		pq->head = pq->tail = newnode; 
	}
	else
	{
		pq->tail->next = newnode;
		pq->tail = pq->tail->next;
	}
}

void QueuePop(Queue* pq)
{
	assert(pq);
	assert(!QueueEmpty(pq));
	if (pq->head->next == NULL)
	{
		free(pq->head);
		pq->head = pq->tail = NULL;
	}
	else
	{
		QueueNode* del = pq->head;
		pq->head = pq->head->next;
		free(del);
		del = NULL;
	}
}

QDataType QueueFront(Queue* pq)
{
	assert(pq);
	assert(pq->head);
	return pq->head->data;
}

QDataType QueueBack(Queue* pq)
{
	assert(pq);
	assert(pq->head);
	return pq->head->data;
}

int QueueEmpty(Queue* pq)
{
	return pq->head == NULL;  
}

int QueueSize(Queue* pq)
{
	QueueNode* cur = pq->head;
	int size = 0;
	assert(pq);
	while (cur)
	{
		++size;
		cur = cur->next;
	}
	return size;
}
